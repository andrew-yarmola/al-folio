% Input the length, steps, eps, delta, tolerance, inner,up, b

function f = qconf_vpa_step(L_in, steps, eps, delta, tolerance, inner,up, b)


    digits(30);
    
    format long
    V = []; % Vertices
    A = []; % Angles
    eps_orig = vpa(eps);
    delta = vpa(delta);
    L_in = vpa(L_in);
    tolerance = vpa(tolerance);
    
    % Bridgeman Point
    if b == 0
        b = vpa(2i*acos(-sinh(L_in/2)));
    end

    b
    
    syms x z t L
   
    % Hill function
    h(x) = acos(tanh(x));
    h_prime(x) = -sech(x);
    
    a(x,L) = h(x)-h(x-L)-L*h_prime(x);
    
    % Let c(L) be the solution to a(x,L) == 0
    c = @(L1) vpasolve(a(x,L1)==0, x, 0.3);
   
    % The inverse of c(L) must find the point x1 where the line
    % h'(x1)(x-x1)+h(x1) intesects the graph h(x)
    c_inv = @(x1) vpa(x1 - vpasolve(h_prime(x1)*(t-x1)+h(x1)==h(t), t, [-inf, -x1]));
    
    % This is computed by differentiating a(x,L)
    c_prime = @(L1) vpa(1/(1-L1*sech(c(L1))*tanh(c(L1))/(sech(c(L1)-L1)-sech(c(L1)))));
    
    % This function is just L*sech(c(L))
    G = @(L1) vpa(L1*sech(c(L1)));
    
    % To define the inverse of G(L), we first note that if y = G(L)
    % then y/L = sech(c(L)) = -h'(c(L)) and acosh(L/y) = c(L).
    % So we must solve a(acosh(L/y),L) == 0
    % One last optimization we make is that
    % h(asech(y/L)) = ArcCos(sqrt(1-y^2/L^2))
    
    G_inv = @(y) vpasolve(acos(sqrt(1-y^2/L^2))-h(acosh(L/y)-L)+y==0,L,[y,y+1000*y]); % Range here is sufficient for our computations
    
    % Simply from c'(L)
    G_prime = @(L1) vpa(sech(c(L1))*(1 - L1*tanh(c(L1))*c_prime(L1)));
        
    gL = vpa(G(L_in))
    
    % These functions give emdeddeness bounds. Called f(x,L) in the paper
    F1a(z) =  exp(abs(z)/2);
    F1b(z) = asinh(exp(abs(z))*sinh(L_in))/L_in;
    F1 = @(x1) min(double(F1a(x1)), double(F1b(x1)));
    
    % For all of the inverse functions, we assume the output is positive.
    F1a_inv(z) = 2*log(z);
    F1b_inv(z) = log(sinh(L_in*z)*csch(L_in));
    F1_inv = @(y) max(double(F1a_inv(y)), double(F1b_inv(y)));
    
    % Usually we have
    % F2 = @(x) max(L_in*exp(-abs(x)/2), asinh(exp(-abs(x))*sinh(L_in)));
    % But L_in > 0 and less than the solution to 2*tanh(L) = L,
    % L_in*exp(-abs(x)/2) always wins out
    F2(z) = L_in*exp(-abs(z)/2);
    F2_prime(z) = -L_in*exp(-z/2)/2; % Only valid for x1 >=0
   
    GF1a(z) = gL/ceil(F1a(z));
    GF1b(z) = gL/ceil(F1b(z));
   
    GF2 = @(x1) vpa(G(F2(x1)));
    Q = @(x1) max([double(GF1a(x1)),double(GF1b(x1)),double(GF2(x1))]);
       
    GF2_inv = @(y) vpa(2*log(L_in/G_inv(y)));
    GF2_prime = @(x1) vpa(G_prime(F2(x1))*F2_prime(x1)); % Only valid for x > 0
    
    DGFa = @(x1) vpa(GF1a(x1) - GF2(x1));
    DGFb = @(x1) vpa(GF1b(x1) - GF2(x1));
    DF1 = @(x1) vpa(F1a(x1) - F1b(x1)); % If <= 0 then F1 = F1a, otherwise F1 = F1b
    
    fplot(@(x)-Q(x),[-5 5 -double(gL) 0.1])
    
    rp = vpa(0);
    cp = GF2(0);
    pcp = cp;
    prp = rp;
    
    %V = [-GF2(0)*1i]; % Initialize the vertex set
    V = [];
    
    nZ = vpa(0); %Point where we switch between GF1 and GF2  
    n = 0; % step count
        
    while n-1 < steps
                
        % non step function wins. this happens first
        if (DF1(rp+delta) <= 0 && DGFa(rp+delta) <= 0) || (DF1(rp+delta) > 0 && DGFb(rp+delta) <= 0) && n-1 < steps
               
            k = vpa(1);
            eps = eps_orig; % We use a more preciv
            
            % It's fine if we miss a small enough intersection as then we
            % are simply cutting of a tiny corner of the step function
            while (DF1(rp+k*delta) <= 0 && DGFa(rp+k*delta) <= 0) || (DF1(rp+k*delta) > 0 && DGFb(rp+k*delta) <= 0)
                          
                % 20 is arbibrary
                if k*delta > 20
                    nZ = Inf; % Happens if we don't switch between GF2and GF1 for too long
                    break
                end
               
                k = k+1;
            
            end          
                        
            % Note, the intersection point in this direction has to be on a
            % flat of F1 (not at a vertical jump)
            if nZ ~= Inf
                if DF1(rp+k*delta) <= 0 && DF1(rp+(k-1)*delta) <= 0
                    nZ = GF2_inv(GF1a(rp+(k-0.5)*delta));
                elseif DF1(rp+k*delta) > 0 && DF1(rp+(k-1)*delta) > 0
                    nZ = GF2_inv(GF1b(rp+(k-0.5)*delta));
                else
                    'No intersection found'
                    nZ = Inf;
                end
            end
                                        
            k = vpa(1);
            % Make sure we can find the x-value that gives a y value of
            % cp-k*eps
            
            eps = 0.00001;
            
            while isempty(G_inv(cp-k*eps)) && (cp-k*eps > 0)
                k = k+1;
            end
            
            prp = rp;
            
            if cp-k*eps > 0
               rp = GF2_inv(cp-k*eps);
            else
               break;
            end
            
            if rp < 0
                rp = -rp;
            end
            
            eps = eps_orig;
            
            while 0 < nZ-rp && n-1 < steps && cp-k*eps > 0
                
                pcp = cp;
                cp = GF2(rp);
                
                if abs(cp) < 2*eps
                    eps = eps/2;
                end
                      
                if n == 0
                    V = [-rp - cp*1i, rp - cp*1i];
                else
                %    V = [-rp - cp*1i, -prp - cp*1i, V, prp - cp*1i, rp - cp*1i];
                    V = [-prp - cp*1i, V, prp - cp*1i];
                end
                
                n = n+1
                
                % Make sure we can find the x-value that gives a y value of
                % cp-k*eps
                while isempty(G_inv(cp-k*eps)) && cp-k*eps > 0
                    k = k+1;
                end
                
                prp = rp;
                
                if cp-k*eps > 0
                    rp = GF2_inv(cp-k*eps);
                else
                    break;
                end
                
                if rp < 0
                    rp = -rp;
                end
                
            end
            
            if nZ ~= Inf
                rp = nZ;
                cp = GF2(rp);
                V = [-rp - cp*1i, -prp - cp*1i, V, prp - cp*1i, rp - cp*1i];
                % Check if the function jumps vertically to the step function
                                
                if DF1(rp+delta) <= 0 && abs(cp - GF1a(rp+delta)) > tolerance
                    cp = GF1a(rp+delta);
                    V = [-rp - cp*1i, V, rp - cp*1i]; % We use the same rp
                elseif DF1(rp+delta) > 0 && abs(cp - GF1b(rp+delta)) > tolerance
                    cp = GF1b(rp+delta);
                    V = [-rp - cp*1i, V, rp - cp*1i]; % We use the same rp
                end
            end
        end
        
        % Step function wins
        if (DF1(rp+delta) <= 0 && DGFa(rp+delta) > 0) || (DF1(rp+delta) > 0 && DGFb(rp+delta) > 0) && n-1 < steps
              
            k = vpa(1);

            while (DF1(rp+k*delta) <= 0 && DGFa(rp+k*delta) > 0) || (DF1(rp+k*delta) > 0 && DGFb(rp+k*delta) > 0)
                % 20 is arbibrary
                if k*delta > 20
                    nZ = Inf; % Happens if we don't switch between GF2and GF1 for x < 20
                    break
                end
                k = k+1;  
            end
                        
            if nZ ~= Inf
                if DF1(rp+k*delta) <= 0 && DF1(rp+(k-1)*delta) <= 0
                    nZ = F1a_inv(ceil(F1a(rp+(k-1)*delta)));
                elseif DF1(rp+k*delta) > 0 && DF1(rp+(k-1)*delta) > 0
                    nZ = F1b_inv(ceil(F1b(rp+(k-1)*delta)));
                else
                    'No intersection found'
                    nZ = Inf;
                end
            end
            
            % Constuct vertices for the step part

            if DF1(rp+delta) <= 0
                pcp = GF1a(rp+delta);
                rp = F1a_inv(ceil(F1a(rp+delta)));
            elseif DF1(rp+delta) > 0
                pcp = GF1b(rp+delta);
                rp = F1b_inv(ceil(F1b(rp+delta)));
            else
                throw('error');
            end
                        
            if rp < 0
                rp = -rp;
            end

            while 0 < nZ-rp && n-1 < steps
                
                if DF1(rp+delta) <= 0
                    cp = GF1a(rp+delta);
                elseif DF1(rp+delta) > 0
                    cp = GF1b(rp+delta);
                end
                
                V = [-rp - i*cp, -rp - i*pcp, V, rp - i*pcp, rp - i*cp];
                
                n = n+1
                
                if DF1(rp+delta) <= 0
                    pcp = GF1a(rp+delta);
                    rp = F1a_inv(ceil(F1a(rp+delta)));
                elseif DF1(rp+delta) > 0
                    pcp = GF1b(rp+delta);
                    rp = F1b_inv(ceil(F1b(rp+delta)));
                else
                    throw('error');
                end
                
                if rp < 0
                    rp = -rp;
                end
                
            end

            if nZ ~= Inf
                rp = nZ;
                cp = GF2(rp);
                V = [-rp + i*cp, V, rp + i*cp];
            end
        end        
    end
    
    if (inner ~= 0)
        V = [-rp, V, rp];
    end
            
    % Convert to double
    W = double(V);
    
    % Compute the angles
    A = (scangle(W) + 1)';
    
    % Add point at infinity
    W = [W, Inf];
    
    if up ~= 0
        A(1,1) = A(1,1) + 0.5;
        A(1,end) = A(1,end) + 0.5;
        A = [A, 0];
    else
        A(1,1) = A(1,1) + 1;
        A(1,end) = A(1,end) +1;
        A = [A, -1];
    end       

    
    figure
    p =  polygon(W,A);
    plot(p,'num');
    delete(findall(gcf,'type','text'));
    axis(double([-rp/2 rp/2 -gL 0]));
    set(gca,'DataAspectRatio', [14 1 1]);

    save('latest_run.mat');
    
    f = hplmap(p);
    f = hplmap(f, p);
    acc = accuracy(f);
    if acc > tolerance
        f = hplmap(f, p, scmapopt('Tolerance',double(tolerance))); % Tries to improve accuracy
        acc = accuracy(f);
    end
    
    hc = evalinv(f,0,acc)
    hb = evalinv(f,double(b),acc)
    
    hdistance = 2* atanh(abs(hb - hc)/abs(hb - conj(hc)))
    keq = exp(hdistance)