% Input the length, eps, steps,tolerance, inner,up, b

function f = qconf_optimal(L, steps, eps,tolerance, inner,up, b)

    V = []; % Vertices
    A = []; % Angles
    delta = 0.01;
    
    if b == 0
        b = (2*acos(-sinh(L/2)))*i; % Bridgeman Point
    end

    b
   
    gL = 2*asin(tanh(L/2));
    
    F1 = @(x)(min(L*exp(abs(x)/2), asinh(exp(abs(x))*sinh(L)))/L);
    F2 = @(x)(max(L*exp(-abs(x)/2), asinh(exp(-abs(x))*sinh(L))));
    
    Q = @(x)(- max(gL/ceil(F1(x)),2*asin(tanh(F2(x)/2))));
    
    fplot(Q,[-10 10 -L 0.1])
    
    return
    
    Qinv = @(y)(fzero(@(x)Q(x) - y,1));
    F1inv = @(y)(fzero(@(x)F1(x) - y,2));
    
    gF1 = @(x)(gL/ceil(F1(x)));
    gF2 = @(x)(2*asin(tanh(F2(x)/2)));
    
    D = @(x)(gF1(x) - gF2(x));
        
    fplot(@(x)[-gF1(x),-gF2(x)],[-10 10 -1 0.1])
    
    figure
    fplot(D,[-10 10])
    
    rp = 0;
    cp = Q(0);
    pcp = 0;
    
    nZ = 0;
       
    n = 0;
    k = 1;

    while n-1 < steps
        
        if D(rp+delta) > 0 % Step function wins
            
            while D(rp+k*delta) >= 0
                
                if k*delta > 20
                    nZ = Inf;
                    break
                end
               
                k = k+1;
            end
            
            if nZ ~= Inf
                nZ = fzero(D, [rp+delta, rp+k*delta]);
            end
            
            % Constuct vertices for the step part

            pcp = Q(rp+delta);

            rp = F1inv(ceil(F1(rp+delta)));
            
            if rp < 0
                rp = -rp;
            end

            while tolerance < nZ-rp && n-1 < steps
                
                cp = Q(rp+delta);

                V = [-rp + i*cp, -rp + i*pcp, V, rp + i*pcp, rp + i*cp];

                pcp = cp;
                n = n+1;

                rp = F1inv(ceil(F1(rp+delta)));

                if rp < 0
                    rp = -rp;
                end

            end

            if nZ ~= Inf
                rp = nZ;
                cp = Q(rp);
                V = [-rp + i*cp, V, rp + i*cp];
            end
            k = 1;
        end
        
        if sum(size(V)) == 0     
            V = [i*Q(0)];
        end
        
        if D(rp+delta) <= 0 
                        
            while D(rp+k*delta) <= 0
                                
                if k*delta > 20
                    nZ = Inf;
                    break
                end
               
                k = k+1;
            
            end          
            
            if nZ ~= Inf
                nZ = fzero(D, [rp+delta, rp+k*delta]);
            end
            
            k = 1;            
            while isnan(Qinv(cp + k*eps))
                k = k+1;
            end
            
            rp = Qinv(cp + k*eps);
            
            if rp < 0
                rp = -rp;
            end
                        
            while tolerance < nZ-rp && n-1 < steps && cp+k*eps < 0
                                            
                cp = Q(rp);
                
                if abs(cp) < 2*eps
                    eps = eps/2;
                end
            
                V = [-rp + i*cp, V, rp + i*cp];
            
                n = n+1;
            
                k = 1;            
                while isnan(Qinv(cp + k*eps))
                    k = k+1;
                end
                
                rp = Qinv(cp + k*eps);
         
                if rp < 0
                    rp = -rp;
                end            
            end
            
            if nZ ~= Inf
                rp = nZ;
                cp = Q(rp);
                V = [-rp + i*cp, V, rp + i*cp];
                if Q(rp+delta) - cp > tolerance
                   cp = Q(rp+delta);
                   V = [-rp + i*cp, V, rp + i*cp];
                end
            end
            k = 1;
        end        
    end
    
    if (inner ~= 0)
        V = [-rp, V, rp];
    end
        
    % Compute the angles
    A = (scangle(V) + 1)';
    
    % Add point at infinity
    V = [V, Inf];
    if up ~= 0
        A(1,1) = A(1,1) + 0.5;
        A(1,end) = A(1,end) + 0.5;
        A = [A, 0];
    else
        A(1,1) = A(1,1) + 1;
        A(1,end) = A(1,end) +1;
        A = [A, -1];
    end       

    figure
    p =  polygon(V,A);
    plot(p,'num')
    axis([-10 10 -1 0.1])
    set(gca,'DataAspectRatio', [14 1 1])

    f = hplmap(p);
    f = hplmap(f, p);
    acc = accuracy(f);
    if acc > tolerance
        f = hplmap(f, p, scmapopt('Tolerance',tolerance)); % Tries to improve accuracy
        acc = accuracy(f);
    end
    
    hc = evalinv(f,0,acc)
    hb = evalinv(f,b,acc)
    
    hdistance = 2* atanh(abs(hb - hc)/abs(hb - conj(hc)))
    keq = exp(hdistance)
    
    
    
    

    
